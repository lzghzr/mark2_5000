# 警告
warning () {
  ui_print "***************************************"
  ui_print "********     ！！！警告！！！   *********"
  ui_print "***************************************"
  ui_print "**  请确保手边有电脑并且已备份boot.img  **"
  ui_print "**  本脚本仅适用于个别 Xperia 设备      **"
  ui_print "**  安装后需重启                       **"
  ui_print "**  成功后虽然使用没什么影响            **"
  ui_print "**  但因为备份可能随magisk更新过期      **"
  ui_print "**  所以请及时卸载                     **"
  ui_print "***************************************"
  ui_print "**  重启后有极大概率黑屏死机，请谨慎使用  **"
  ui_print "**  重启后有极大概率黑屏死机，请谨慎使用  **"
  ui_print "**  重启后有极大概率黑屏死机，请谨慎使用  **"
  ui_print "***************************************"
}

# 首次安装提示
TIMESTAMP=`date +%s`
DIRPATH=/data/adb/xperia_battery_age
if [ -d $DIRPATH ]; then
  DIRTIMESTAMP=`stat -c %Y $DIRPATH`
  TIMECHA=$(( $DIRTIMESTAMP - $TIMESTAMP + 300 ))
  if [ $TIMECHA -gt 0 ]; then
    warning
    ui_print "**  距上次安装不足300秒                **"
    ui_print "**  请再仔细考虑${TIMECHA}秒后再次安装         **"
    abort "***************************************"
  fi
else
  warning
  ui_print "**  因为本次为首次安装，即将退出         **"
  ui_print "**  请仔细考虑300秒后再次安装           **"
  mkdir $DIRPATH
  abort "***************************************"
fi

# 显示警告信息
warning

# 设置路径
MAGISKPATH=/data/adb/magisk

# 获取当前插槽
SLOT=$(getprop ro.boot.slot_suffix)

if [ "$SLOT" != "_a" ] && [ $SLOT != "_b" ]; then
  ui_print "**  未获取到正确插槽                   **"
  abort "***************************************"
else
  # 提取boot.img
  dd if=/dev/block/by-name/boot$SLOT of=$DIRPATH/boot.img &> /dev/null
fi

if [ $? != 0 ]; then
  ui_print "**  未能提取到boot.img                **"
  abort "***************************************"
fi

# 备份boot.img
cp -rf $DIRPATH/boot.img $DIRPATH/boot_0.img

# 为boot.img打补丁
CONt=0

# Android 10
# somc_fg_gen4_restore_batt_aging_level_from_sram
$MAGISKPATH/magiskboot hexpatch $DIRPATH/boot_0.img E243413968D647B9 0200805268D647B9
if [ $? == 0 ]; then
  CONt=$(( $CONt + 1 ))
fi
# somc_fg_gen4_set_batt_aging_level
$MAGISKPATH/magiskboot hexpatch $DIRPATH/boot_0.img E00D0054A80240B9 E00D005408008052
if [ $? == 0 ]; then
  CONt=$(( $CONt + 1 ))
fi

# Android 12
# somc_fg_gen4_restore_batt_aging_level_from_sram
$MAGISKPATH/magiskboot hexpatch $DIRPATH/boot_0.img A2035D38686E49B9 02008052686E49B9
if [ $? == 0 ]; then
  CONt=$(( $CONt + 1 ))
fi
# somc_fg_gen4_set_batt_aging_level
$MAGISKPATH/magiskboot hexpatch $DIRPATH/boot_0.img 000E0054A80240B9 000E005408008052
if [ $? == 0 ]; then
  CONt=$(( $CONt + 1 ))
fi

# LineageOS_20
# somc_fg_gen4_restore_batt_aging_level_from_sram
$MAGISKPATH/magiskboot hexpatch $DIRPATH/boot_0.img E2134039686E49B9 02008052686E49B9
if [ $? == 0 ]; then
  CONt=$(( $CONt + 1 ))
fi
# somc_fg_gen4_set_batt_aging_level
$MAGISKPATH/magiskboot hexpatch $DIRPATH/boot_0.img E00D0054A80240B9 E00D005408008052
if [ $? == 0 ]; then
  CONt=$(( $CONt + 1 ))
fi

if [ $CONt != 2 ]; then
  ui_print "**  不支持此设备                      **"
  abort "***************************************"
fi

# 刷入boot
dd if=$DIRPATH/boot_0.img of=/dev/block/by-name/boot$SLOT &> /dev/null

if [ $? != 0 ]; then
  ui_print "**  未能刷入boot_0.img                **"
  abort "***************************************"
fi

ui_print "**  安装成功，请重启设备                **"
ui_print "***************************************"
