# 安装时创建
DIRPATH=/data/adb/xperia_battery_age 

# 获取当前插槽
SLOT=$(getprop ro.boot.slot_suffix)

if [ "$SLOT" != "_a" ] && [ $SLOT != "_b" ]; then
  echo "未获取到正确插槽"
  exit 1
else
  # 还原boot.img
  dd if=$DIRPATH/boot.img of=/dev/block/by-name/boot$SLOT &> /dev/null
fi

if [ $? != 0 ]; then
  echo "未能还原boot.img"
  exit 1
fi

echo "bye"
# 清理残留
rm -rf $DIRPATH
